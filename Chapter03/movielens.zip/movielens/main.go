package main

import (
	"fmt"
	"github.com/yunabe/easycsv"
	. "gorgonia.org/gorgonia"
	"gorgonia.org/tensor"
	"log"
)

var datasetfilename = "dataset/cleanratings.dat"
var movieindexfilename = "dataset/cleanmovies.dat"

func BuildMovieIndex(input string) map[int]string {
	var entrycount int
	r := easycsv.NewReaderFile(input, easycsv.Option{Comma: ','})
	var entry struct {
		Id    int    `index:"0"`
		Title string `index:"1"`
	}
	//fix hardcode
	movieindex := make(map[int]string, 3952)

	for r.Read(&entry) {
		//fmt.Println(entry)
		movieindex[entry.Id] = entry.Title
		entrycount++
	}
	return movieindex
}

func DataImport(input string) (out [][]int, uniquemoives map[int]int) {
	//initial data processing
	//import from csv  read into entries var
	r := easycsv.NewReaderFile(input, easycsv.Option{
		Comma: ',',
	})
	var entry []int
	var entries [][]int
	for r.Read(&entry) {
		entries = append(entries, entry)
	}

	//map for if unique true/false
	seenuser := make(map[int]bool)
	seenmovie := make(map[int]bool)
	//maps for if unique index
	uniqueusers := make(map[int]int)
	uniquemoives = make(map[int]int)

	uniqueuserscount := 0
	uniquemoivescount := 0

	//distinct movie lists/indices
	for _, e := range entries {
		if seenmovie[e[1]] == false {
			uniquemoives[uniquemoivescount] = e[1]
			seenmovie[e[1]] = true
			uniquemoivescount++
		} else if seenmovie[e[1]] == true {
			fmt.Printf("seen movie %v before,aborting\n", e[0])
			continue
		}
	}

	//distinct movie lists/indices
	for _, e := range entries {
		if seenuser[e[0]] == false {
			uniqueusers[uniqueuserscount] = e[0]
			seenuser[e[0]] = true
			uniqueuserscount++
		} else if seenuser[e[0]] == true {
			fmt.Printf("seen user %v before,aborting\n", e[0])
			continue
		}
	}

	uservecs := make([][]int, len(uniqueusers))
	for i := range uservecs {
		uservecs[i] = make([]int, len(uniquemoives))
	}
	var entriesloop int
	for _, e := range entries {
		// hack - wtf
		if entriesloop%100000 == 0 && entriesloop != 0 {
			fmt.Printf("Processing rating %v of %v\n", entriesloop, len(entries))
		}
		if entriesloop > 999866 {
			break
		}
		var currlike int

		//normalize ratings
		if e[2] >= 4 {
			currlike = 1
		} else {
			currlike = 0
		}

		//add to a user's vector of index e[1]/movie num whether current movie is +1
		//fmt.Println("Now looping uniquemovies")
		for i, v := range uniquemoives {
			if v == e[1] {
				//fmt.Println("Now adding to uservecs to currlike")
				uservecs[e[0]][i] = currlike
				break
			}
		}
		entriesloop++
	}
	fmt.Println(uservecs)

	fmt.Println(entry)
	if err := r.Done(); err != nil {
		log.Fatal("Failed to read a csv file :%v", err)
	}
	fmt.Printf("length uservecs and uservecs.movies %v", len(uservecs))
	fmt.Println("Number of unique user:", len(seenuser))
	fmt.Println("Number of unique movies:", len(seenmovie))
	out = uservecs
	return
}

const cdS = 1

type ggRBM struct {
	g         *ExprGraph
	v         *Node //visible units
	vB        *Node // visible unit biases - same size tensor as v
	h         *Node // hidden units
	hB        *Node //hidden unit biases - same size tensor as h
	w         *Node //connection weights
	cdSamples int   //number of samples for contrastive divergence - WHAT ABOUT NOMENTUM
}

func (r *ggRBM) learnables() Nodes {
	return Nodes{r.w, r.vB, r.hB}
}

//uses Gibbs Sampling
func (r *ggRBM) ContrastiveDivergence(input *Node, learnRate float64, k int) {
	rows := float64(r.g.TrainingSize)
	//CD-K
	phMeans, phSamples := r.SampleHiddenFromVisible(input)
	nvSamples := make([]float64, r.Inputs)
	_, nvSamples, nhMeans, nhSamples := r.Gibbs(phSamples, nvSamples)
	for step := 0; step < k; step++ {
		_, nvSamples, nhMeans, nhSamples = r.Gibbs(phSamples, nvSamples)
	}

	//Update weights
	for i := 0; i < r.Outputs; i++ {
		for j := 0; j < r.Inputs; j++ {
			r.Weights[i][j] += learnRate * (phMeans[i]*input[j] - nhMeans[i]*nvSamples[j]) / rows
		}
		r.Biases[i] += learnRate * (phSamples[i] - nhMeans[i]) / rows
	}
	//update hidden biases
	for j := 0; j < r.Inputs; j++ {
		r.VisibleBiases[j] += learnRate * (input[j] - nvSamples[j]) / rows
	}
}

func (r *ggRBM) SampleHiddenFromVisible(vInput *Node) (means []float64, samples []float64) {
	means = make([]float64, r.Outputs)
	samples = make([]float64, r.Outputs)
	for i := 0; i < r.Outputs; i++ {
		mean := r.PropagateUp(vInput, r.Weights[i], r.Biases[i])
		samples[i] = float64(binomial(1, mean))
		means[i] = mean
	}
	return means, samples
}

func (r *ggRBM) SampleHiddenFromHidden(hInput *Node) (means []float64, samples []float64) {
	means = make([]float64, r.Iutputs)
	samples = make([]float64, r.Iutputs)
	for i := 0; i < r.Iutputs; i++ {
		mean := r.PropagateDown(hInput, i, r.VisibleBiases[i])
		samples[i] = float64(binomial(1, mean))
		means[i] = mean
	}
	return means, samples
}

func (r *ggRBM) PropagateDown(h *Node, j int, hB *Node) *Node {
	retVal := 0.0
	for i := 0; i < r.Outputs; i++ {
		retVal += r.Weights[i][j] * h0[i]
	}
	retVal += bias
	return sigmod(retVal)
}

func (r *ggRBM) PropagateUp(v *Node, w *Node, hB *Node) *Node {
	retVal := 0.0
	for i := 0; i < r.Outputs; i++ {
		retVal += weights[j] * v0[i]
	}
	retVal += bias
	return sigmod(retVal)
}

func (r *ggRBM) Gibbs(h, v *Node) (vMeans []float64, vSamples []float64, hMeans []float64, hSamples []float64) {
	vMeans, vSamples = r.SampleHiddenFromHidden(r.h)
	hMeans, hSamples = r.SampleHiddenFromVisible(r.v)
	return
}
func (r *ggRBM) Reconstruct(x *Node) *Node {
	hiddenLayer := make([]float64, r.Outputs)
	retVal := make([]float64, r.Inputs)
	for i := 0; i < r.Outputs; i++ {
		hiddenLayer[i] = r.PropagateUp(x, r.Weights[i], r.Biases[i])
	}
	for j := 0; j < r.Inputs; j++ {
		activated := 0.0
		for i := 0; i < r.Outputs; i++ {
			activated += r.Weights[i][j] * hiddenLayer[i]
		}
		activated += r.VisibleBiases[j]
		retVal[j] = sigmoid(activated)
	}
	return retVal
}

func newggRBM(g *ExprGraph, cdS int) *ggRBM {
	vT := tensor.New(tensor.WithBacking(tensor.Random(tensor.Int, 3952)), tensor.WithShape(3952, 1))

	v := NewMatrix(g, tensor.Int, WithName("v"), WithShape(3952, 1), WithValue(vT))
	hT := tensor.New(tensor.WithBacking(tensor.Random(tensor.Int, 200)), tensor.WithShape(200, 1))

	h := NewMatrix(g, tensor.Int, WithName("h"), WithShape(200, 1), WithValue(vT))

	wB := tensor.Random(tensor.Float64, 3952*200)
	wT := tensor.New(tensor.WithBacking(wB), tensor.WithShape(3952*200, 1))
	w := NewMatrix(g, tensor.Float64, WithName("w"), WithShape(3952*200, 1), WithValue(wT))

	return &ggRBM{
		g:         g,
		v:         v,
		h:         h,
		w:         w,
		cdSamples: cdS,
	}
}

func main() {
	g := NewGraph()
	m := newggRBM(g, cdS)
	data, err := ReadDataFile(datasetfilename)
	if err != nil {
		log.Fatal(err)
	}
	fmt.Println("Data read from csv:\n", data)
	vm := NewTapeMachine(g, BindDualValues(m.learnables()...))
	for i := 0; i < 1; i++ {
		if err = vm.RunAll(); err != nil {
			log.Fatal(err)
		}
	}
}
