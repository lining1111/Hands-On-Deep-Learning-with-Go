#!/bin/bash
export LC_CTYPE=C
export LANG=C
cat ratings.dat | sed 's/::/,/g' > cleanratings.dat
cat movies.dat | sed 's/::/,/g' > cleanmovies.dat